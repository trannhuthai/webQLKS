<?php
define('HOST', 'localhost');
define('DATABASE', 'webqlks');
define('USERNAME', 'root');
define('PASSWORD', '');
define('PRIVATE_KEY','kjdkwuhdkehfd(0cqwdnkf0cnwkw)');