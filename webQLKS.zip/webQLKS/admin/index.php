<?php
	$title = 'Dashboard Page';
	$baseUrl = '';
	require_once('layouts/header.php');

	
?>

<div class="row">
	<div class="col-md-12">
		<h1>Dashboard</h1>
	</div>
</div>

<?php
	require_once('layouts/footer.php');
?>